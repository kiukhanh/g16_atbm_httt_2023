﻿namespace Phanhe1
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Main));
            this.PANEL_MAIN = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel9 = new Guna.UI2.WinForms.Guna2Panel();
            this.view_kiem_tra = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox7 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel8 = new Guna.UI2.WinForms.Guna2Panel();
            this.view_thu_hoi = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox6 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            this.view_phan_role = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.view_phan_quyen = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.view_thao_tac = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.button_view_information = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.button_view_user = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.PANEL_MAIN.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).BeginInit();
            this.guna2Panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).BeginInit();
            this.guna2Panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).BeginInit();
            this.guna2Panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            this.guna2Panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            this.guna2Panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            this.guna2Panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // PANEL_MAIN
            // 
            this.PANEL_MAIN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(95)))), ((int)(((byte)(87)))));
            this.PANEL_MAIN.Controls.Add(this.guna2Panel2);
            this.PANEL_MAIN.Controls.Add(this.label1);
            this.PANEL_MAIN.Location = new System.Drawing.Point(-17, -5);
            this.PANEL_MAIN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PANEL_MAIN.Name = "PANEL_MAIN";
            this.PANEL_MAIN.Size = new System.Drawing.Size(1221, 639);
            this.PANEL_MAIN.TabIndex = 1;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2Panel9);
            this.guna2Panel2.Controls.Add(this.guna2Panel8);
            this.guna2Panel2.Controls.Add(this.guna2Panel7);
            this.guna2Panel2.Controls.Add(this.guna2Panel6);
            this.guna2Panel2.Controls.Add(this.guna2Panel5);
            this.guna2Panel2.Controls.Add(this.guna2Panel4);
            this.guna2Panel2.Controls.Add(this.guna2Panel3);
            this.guna2Panel2.Location = new System.Drawing.Point(60, 92);
            this.guna2Panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1085, 487);
            this.guna2Panel2.TabIndex = 1;
            this.guna2Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel2_Paint);
            // 
            // guna2Panel9
            // 
            this.guna2Panel9.BorderColor = System.Drawing.Color.Yellow;
            this.guna2Panel9.BorderThickness = 2;
            this.guna2Panel9.Controls.Add(this.view_kiem_tra);
            this.guna2Panel9.Controls.Add(this.guna2PictureBox7);
            this.guna2Panel9.Location = new System.Drawing.Point(432, 257);
            this.guna2Panel9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel9.Name = "guna2Panel9";
            this.guna2Panel9.Size = new System.Drawing.Size(216, 165);
            this.guna2Panel9.TabIndex = 4;
            // 
            // view_kiem_tra
            // 
            this.view_kiem_tra.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.view_kiem_tra.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.view_kiem_tra.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.view_kiem_tra.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.view_kiem_tra.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(95)))), ((int)(((byte)(87)))));
            this.view_kiem_tra.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_kiem_tra.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(238)))), ((int)(((byte)(221)))));
            this.view_kiem_tra.Location = new System.Drawing.Point(3, 102);
            this.view_kiem_tra.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.view_kiem_tra.Name = "view_kiem_tra";
            this.view_kiem_tra.Size = new System.Drawing.Size(201, 60);
            this.view_kiem_tra.TabIndex = 9;
            this.view_kiem_tra.Text = "KIỂM TRA QUYỀN ROLE";
            this.view_kiem_tra.Click += new System.EventHandler(this.view_kiem_tra_Click);
            // 
            // guna2PictureBox7
            // 
            this.guna2PictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox7.Image")));
            this.guna2PictureBox7.ImageRotate = 0F;
            this.guna2PictureBox7.Location = new System.Drawing.Point(40, 23);
            this.guna2PictureBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2PictureBox7.Name = "guna2PictureBox7";
            this.guna2PictureBox7.Size = new System.Drawing.Size(125, 82);
            this.guna2PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox7.TabIndex = 1;
            this.guna2PictureBox7.TabStop = false;
            // 
            // guna2Panel8
            // 
            this.guna2Panel8.BorderColor = System.Drawing.Color.Yellow;
            this.guna2Panel8.BorderThickness = 2;
            this.guna2Panel8.Controls.Add(this.view_thu_hoi);
            this.guna2Panel8.Controls.Add(this.guna2PictureBox6);
            this.guna2Panel8.Location = new System.Drawing.Point(125, 257);
            this.guna2Panel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel8.Name = "guna2Panel8";
            this.guna2Panel8.Size = new System.Drawing.Size(216, 165);
            this.guna2Panel8.TabIndex = 3;
            // 
            // view_thu_hoi
            // 
            this.view_thu_hoi.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.view_thu_hoi.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.view_thu_hoi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.view_thu_hoi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.view_thu_hoi.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(95)))), ((int)(((byte)(87)))));
            this.view_thu_hoi.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_thu_hoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(238)))), ((int)(((byte)(221)))));
            this.view_thu_hoi.Location = new System.Drawing.Point(13, 117);
            this.view_thu_hoi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.view_thu_hoi.Name = "view_thu_hoi";
            this.view_thu_hoi.Size = new System.Drawing.Size(180, 46);
            this.view_thu_hoi.TabIndex = 8;
            this.view_thu_hoi.Text = "THU HỒI";
            this.view_thu_hoi.Click += new System.EventHandler(this.view_thu_hoi_Click);
            // 
            // guna2PictureBox6
            // 
            this.guna2PictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox6.Image")));
            this.guna2PictureBox6.ImageRotate = 0F;
            this.guna2PictureBox6.Location = new System.Drawing.Point(40, 23);
            this.guna2PictureBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2PictureBox6.Name = "guna2PictureBox6";
            this.guna2PictureBox6.Size = new System.Drawing.Size(125, 82);
            this.guna2PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox6.TabIndex = 1;
            this.guna2PictureBox6.TabStop = false;
            // 
            // guna2Panel7
            // 
            this.guna2Panel7.BorderColor = System.Drawing.Color.Yellow;
            this.guna2Panel7.BorderThickness = 2;
            this.guna2Panel7.Controls.Add(this.view_phan_role);
            this.guna2Panel7.Controls.Add(this.guna2PictureBox5);
            this.guna2Panel7.Location = new System.Drawing.Point(821, 27);
            this.guna2Panel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel7.Name = "guna2Panel7";
            this.guna2Panel7.Size = new System.Drawing.Size(216, 165);
            this.guna2Panel7.TabIndex = 2;
            // 
            // view_phan_role
            // 
            this.view_phan_role.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.view_phan_role.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.view_phan_role.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.view_phan_role.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.view_phan_role.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(95)))), ((int)(((byte)(87)))));
            this.view_phan_role.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_phan_role.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(238)))), ((int)(((byte)(221)))));
            this.view_phan_role.Location = new System.Drawing.Point(19, 108);
            this.view_phan_role.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.view_phan_role.Name = "view_phan_role";
            this.view_phan_role.Size = new System.Drawing.Size(163, 54);
            this.view_phan_role.TabIndex = 7;
            this.view_phan_role.Text = "PHÂN ROLE CHO USER";
            this.view_phan_role.Click += new System.EventHandler(this.view_phan_role_Click);
            // 
            // guna2PictureBox5
            // 
            this.guna2PictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox5.Image")));
            this.guna2PictureBox5.ImageRotate = 0F;
            this.guna2PictureBox5.Location = new System.Drawing.Point(40, 23);
            this.guna2PictureBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2PictureBox5.Name = "guna2PictureBox5";
            this.guna2PictureBox5.Size = new System.Drawing.Size(125, 82);
            this.guna2PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox5.TabIndex = 1;
            this.guna2PictureBox5.TabStop = false;
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.BorderColor = System.Drawing.Color.Yellow;
            this.guna2Panel6.BorderThickness = 2;
            this.guna2Panel6.Controls.Add(this.view_phan_quyen);
            this.guna2Panel6.Controls.Add(this.guna2PictureBox4);
            this.guna2Panel6.Location = new System.Drawing.Point(564, 27);
            this.guna2Panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.Size = new System.Drawing.Size(216, 165);
            this.guna2Panel6.TabIndex = 4;
            // 
            // view_phan_quyen
            // 
            this.view_phan_quyen.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.view_phan_quyen.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.view_phan_quyen.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.view_phan_quyen.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.view_phan_quyen.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(95)))), ((int)(((byte)(87)))));
            this.view_phan_quyen.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_phan_quyen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(238)))), ((int)(((byte)(221)))));
            this.view_phan_quyen.Location = new System.Drawing.Point(16, 111);
            this.view_phan_quyen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.view_phan_quyen.Name = "view_phan_quyen";
            this.view_phan_quyen.Size = new System.Drawing.Size(180, 46);
            this.view_phan_quyen.TabIndex = 8;
            this.view_phan_quyen.Text = "PHÂN QUYỀN";
            this.view_phan_quyen.Click += new System.EventHandler(this.view_phan_quyen_Click);
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox4.Image")));
            this.guna2PictureBox4.ImageRotate = 0F;
            this.guna2PictureBox4.Location = new System.Drawing.Point(40, 23);
            this.guna2PictureBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.Size = new System.Drawing.Size(125, 82);
            this.guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox4.TabIndex = 1;
            this.guna2PictureBox4.TabStop = false;
            // 
            // guna2Panel5
            // 
            this.guna2Panel5.BorderColor = System.Drawing.Color.Yellow;
            this.guna2Panel5.BorderThickness = 2;
            this.guna2Panel5.Controls.Add(this.view_thao_tac);
            this.guna2Panel5.Controls.Add(this.guna2PictureBox3);
            this.guna2Panel5.Location = new System.Drawing.Point(304, 27);
            this.guna2Panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel5.Name = "guna2Panel5";
            this.guna2Panel5.Size = new System.Drawing.Size(216, 165);
            this.guna2Panel5.TabIndex = 3;
            // 
            // view_thao_tac
            // 
            this.view_thao_tac.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.view_thao_tac.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.view_thao_tac.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.view_thao_tac.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.view_thao_tac.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(95)))), ((int)(((byte)(87)))));
            this.view_thao_tac.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_thao_tac.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(238)))), ((int)(((byte)(221)))));
            this.view_thao_tac.Location = new System.Drawing.Point(11, 108);
            this.view_thao_tac.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.view_thao_tac.Name = "view_thao_tac";
            this.view_thao_tac.Size = new System.Drawing.Size(195, 54);
            this.view_thao_tac.TabIndex = 8;
            this.view_thao_tac.Text = "THAO TÁC USER/ROLE";
            this.view_thao_tac.Click += new System.EventHandler(this.view_thao_tac_Click_1);
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.ImageRotate = 0F;
            this.guna2PictureBox3.Location = new System.Drawing.Point(40, 23);
            this.guna2PictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.Size = new System.Drawing.Size(125, 82);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox3.TabIndex = 1;
            this.guna2PictureBox3.TabStop = false;
            // 
            // guna2Panel4
            // 
            this.guna2Panel4.BorderColor = System.Drawing.Color.Yellow;
            this.guna2Panel4.BorderThickness = 2;
            this.guna2Panel4.Controls.Add(this.button_view_information);
            this.guna2Panel4.Controls.Add(this.guna2PictureBox2);
            this.guna2Panel4.Location = new System.Drawing.Point(715, 257);
            this.guna2Panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.Size = new System.Drawing.Size(216, 165);
            this.guna2Panel4.TabIndex = 2;
            // 
            // button_view_information
            // 
            this.button_view_information.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button_view_information.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button_view_information.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button_view_information.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button_view_information.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(95)))), ((int)(((byte)(87)))));
            this.button_view_information.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_view_information.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(238)))), ((int)(((byte)(221)))));
            this.button_view_information.Location = new System.Drawing.Point(3, 108);
            this.button_view_information.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_view_information.Name = "button_view_information";
            this.button_view_information.Size = new System.Drawing.Size(203, 54);
            this.button_view_information.TabIndex = 7;
            this.button_view_information.Text = "KIỂM TRA QUYỀN USER";
            this.button_view_information.Click += new System.EventHandler(this.button_view_information_Click);
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox2.Image")));
            this.guna2PictureBox2.ImageRotate = 0F;
            this.guna2PictureBox2.Location = new System.Drawing.Point(40, 23);
            this.guna2PictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.Size = new System.Drawing.Size(125, 82);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox2.TabIndex = 1;
            this.guna2PictureBox2.TabStop = false;
            this.guna2PictureBox2.Click += new System.EventHandler(this.guna2PictureBox2_Click);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BorderColor = System.Drawing.Color.Yellow;
            this.guna2Panel3.BorderThickness = 2;
            this.guna2Panel3.Controls.Add(this.button_view_user);
            this.guna2Panel3.Controls.Add(this.guna2PictureBox1);
            this.guna2Panel3.Location = new System.Drawing.Point(51, 27);
            this.guna2Panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(216, 165);
            this.guna2Panel3.TabIndex = 0;
            // 
            // button_view_user
            // 
            this.button_view_user.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button_view_user.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button_view_user.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button_view_user.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button_view_user.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(95)))), ((int)(((byte)(87)))));
            this.button_view_user.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_view_user.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(238)))), ((int)(((byte)(221)))));
            this.button_view_user.Location = new System.Drawing.Point(19, 111);
            this.button_view_user.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_view_user.Name = "button_view_user";
            this.button_view_user.PressedColor = System.Drawing.Color.BlanchedAlmond;
            this.button_view_user.Size = new System.Drawing.Size(180, 46);
            this.button_view_user.TabIndex = 6;
            this.button_view_user.Text = "XEM USER";
            this.button_view_user.Click += new System.EventHandler(this.button_view_user_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(40, 23);
            this.guna2PictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(125, 82);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 1;
            this.guna2PictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(177)))), ((int)(((byte)(10)))));
            this.label1.Location = new System.Drawing.Point(315, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(520, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADMIN MANAGEMENT SYSTEM";
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1181, 603);
            this.Controls.Add(this.PANEL_MAIN);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form_Main";
            this.Text = "Form_Main";
            this.Load += new System.EventHandler(this.Form_Main_Load);
            this.PANEL_MAIN.ResumeLayout(false);
            this.PANEL_MAIN.PerformLayout();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).EndInit();
            this.guna2Panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).EndInit();
            this.guna2Panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).EndInit();
            this.guna2Panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            this.guna2Panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            this.guna2Panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            this.guna2Panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel PANEL_MAIN;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel8;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox6;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel9;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox7;
        private Guna.UI2.WinForms.Guna2Button view_kiem_tra;
        private Guna.UI2.WinForms.Guna2Button view_thu_hoi;
        private Guna.UI2.WinForms.Guna2Button view_phan_role;
        private Guna.UI2.WinForms.Guna2Button view_phan_quyen;
        private Guna.UI2.WinForms.Guna2Button view_thao_tac;
        private Guna.UI2.WinForms.Guna2Button button_view_information;
        private Guna.UI2.WinForms.Guna2Button button_view_user;
    }
}