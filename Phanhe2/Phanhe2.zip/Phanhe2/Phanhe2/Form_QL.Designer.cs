﻿namespace Phanhe2
{
    partial class Form_QL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.textBox_ID = new System.Windows.Forms.TextBox();
            this.guna2Button_CaNhan = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_DeAn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_PhongBan = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_NhanVien = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_CongViec = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_PhanCong = new Guna.UI2.WinForms.Guna2Button();
            this.textBox_Hoten = new System.Windows.Forms.TextBox();
            this.label_Hoten = new System.Windows.Forms.Label();
            this.label_Phai = new System.Windows.Forms.Label();
            this.textBox_Phai = new System.Windows.Forms.TextBox();
            this.label_NgSinh = new System.Windows.Forms.Label();
            this.textBox_Ngsinh = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_DiaChi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_SDT = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_PHG = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_NQL = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_Luong = new System.Windows.Forms.TextBox();
            this.label_PhuCap = new System.Windows.Forms.Label();
            this.textBox_PhuCap = new System.Windows.Forms.TextBox();
            this.guna2Button_Sua = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_Luu = new Guna.UI2.WinForms.Guna2Button();
            this.panel_CaNhan = new System.Windows.Forms.Panel();
            this.guna2DataGridView_QL = new Guna.UI2.WinForms.Guna2DataGridView();
            this.panel_CaNhan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView_QL)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.Image = global::Phanhe2.Properties.Resources.Avatar;
            this.guna2ImageButton1.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.ImageSize = new System.Drawing.Size(155, 155);
            this.guna2ImageButton1.Location = new System.Drawing.Point(44, 0);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.Size = new System.Drawing.Size(211, 199);
            this.guna2ImageButton1.TabIndex = 0;
            // 
            // textBox_ID
            // 
            this.textBox_ID.BackColor = System.Drawing.Color.SeaGreen;
            this.textBox_ID.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_ID.ForeColor = System.Drawing.Color.White;
            this.textBox_ID.Location = new System.Drawing.Point(48, 201);
            this.textBox_ID.Name = "textBox_ID";
            this.textBox_ID.Size = new System.Drawing.Size(196, 32);
            this.textBox_ID.TabIndex = 1;
            this.textBox_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // guna2Button_CaNhan
            // 
            this.guna2Button_CaNhan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_CaNhan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_CaNhan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_CaNhan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_CaNhan.FillColor = System.Drawing.Color.White;
            this.guna2Button_CaNhan.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_CaNhan.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_CaNhan.Location = new System.Drawing.Point(33, 249);
            this.guna2Button_CaNhan.Name = "guna2Button_CaNhan";
            this.guna2Button_CaNhan.Size = new System.Drawing.Size(235, 45);
            this.guna2Button_CaNhan.TabIndex = 2;
            this.guna2Button_CaNhan.Text = "CÁ NHÂN";
            this.guna2Button_CaNhan.Click += new System.EventHandler(this.guna2Button_CaNhan_Click);
            // 
            // guna2Button_DeAn
            // 
            this.guna2Button_DeAn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_DeAn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_DeAn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_DeAn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_DeAn.FillColor = System.Drawing.Color.White;
            this.guna2Button_DeAn.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_DeAn.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_DeAn.Location = new System.Drawing.Point(33, 453);
            this.guna2Button_DeAn.Name = "guna2Button_DeAn";
            this.guna2Button_DeAn.Size = new System.Drawing.Size(235, 45);
            this.guna2Button_DeAn.TabIndex = 3;
            this.guna2Button_DeAn.Text = "ĐỀ ÁN";
            this.guna2Button_DeAn.Click += new System.EventHandler(this.guna2Button_DeAn_Click);
            // 
            // guna2Button_PhongBan
            // 
            this.guna2Button_PhongBan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_PhongBan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_PhongBan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_PhongBan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_PhongBan.FillColor = System.Drawing.Color.White;
            this.guna2Button_PhongBan.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_PhongBan.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_PhongBan.Location = new System.Drawing.Point(33, 402);
            this.guna2Button_PhongBan.Name = "guna2Button_PhongBan";
            this.guna2Button_PhongBan.Size = new System.Drawing.Size(235, 45);
            this.guna2Button_PhongBan.TabIndex = 4;
            this.guna2Button_PhongBan.Text = "PHÒNG BAN";
            this.guna2Button_PhongBan.Click += new System.EventHandler(this.guna2Button_PhongBan_Click);
            // 
            // guna2Button_NhanVien
            // 
            this.guna2Button_NhanVien.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_NhanVien.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_NhanVien.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_NhanVien.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_NhanVien.FillColor = System.Drawing.Color.White;
            this.guna2Button_NhanVien.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_NhanVien.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_NhanVien.Location = new System.Drawing.Point(33, 351);
            this.guna2Button_NhanVien.Name = "guna2Button_NhanVien";
            this.guna2Button_NhanVien.Size = new System.Drawing.Size(235, 45);
            this.guna2Button_NhanVien.TabIndex = 5;
            this.guna2Button_NhanVien.Text = "NHÂN VIÊN";
            this.guna2Button_NhanVien.Click += new System.EventHandler(this.guna2Button_NhanVien_Click);
            // 
            // guna2Button_CongViec
            // 
            this.guna2Button_CongViec.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_CongViec.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_CongViec.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_CongViec.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_CongViec.FillColor = System.Drawing.Color.White;
            this.guna2Button_CongViec.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_CongViec.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_CongViec.Location = new System.Drawing.Point(33, 300);
            this.guna2Button_CongViec.Name = "guna2Button_CongViec";
            this.guna2Button_CongViec.Size = new System.Drawing.Size(235, 45);
            this.guna2Button_CongViec.TabIndex = 6;
            this.guna2Button_CongViec.Text = "CÔNG VIỆC";
            this.guna2Button_CongViec.Click += new System.EventHandler(this.guna2Button_CongViec_Click);
            // 
            // guna2Button_PhanCong
            // 
            this.guna2Button_PhanCong.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_PhanCong.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_PhanCong.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_PhanCong.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_PhanCong.FillColor = System.Drawing.Color.White;
            this.guna2Button_PhanCong.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_PhanCong.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_PhanCong.Location = new System.Drawing.Point(33, 504);
            this.guna2Button_PhanCong.Name = "guna2Button_PhanCong";
            this.guna2Button_PhanCong.Size = new System.Drawing.Size(235, 45);
            this.guna2Button_PhanCong.TabIndex = 7;
            this.guna2Button_PhanCong.Text = "PHÂN CÔNG";
            this.guna2Button_PhanCong.Click += new System.EventHandler(this.guna2Button_PhanCong_Click);
            // 
            // textBox_Hoten
            // 
            this.textBox_Hoten.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Hoten.Location = new System.Drawing.Point(34, 50);
            this.textBox_Hoten.Name = "textBox_Hoten";
            this.textBox_Hoten.Size = new System.Drawing.Size(162, 32);
            this.textBox_Hoten.TabIndex = 8;
            // 
            // label_Hoten
            // 
            this.label_Hoten.AutoSize = true;
            this.label_Hoten.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Hoten.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_Hoten.Location = new System.Drawing.Point(39, 27);
            this.label_Hoten.Name = "label_Hoten";
            this.label_Hoten.Size = new System.Drawing.Size(57, 20);
            this.label_Hoten.TabIndex = 9;
            this.label_Hoten.Text = "Họ tên";
            // 
            // label_Phai
            // 
            this.label_Phai.AutoSize = true;
            this.label_Phai.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Phai.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_Phai.Location = new System.Drawing.Point(277, 27);
            this.label_Phai.Name = "label_Phai";
            this.label_Phai.Size = new System.Drawing.Size(41, 20);
            this.label_Phai.TabIndex = 11;
            this.label_Phai.Text = "Phái";
            // 
            // textBox_Phai
            // 
            this.textBox_Phai.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Phai.Location = new System.Drawing.Point(272, 50);
            this.textBox_Phai.Name = "textBox_Phai";
            this.textBox_Phai.Size = new System.Drawing.Size(166, 32);
            this.textBox_Phai.TabIndex = 10;
            // 
            // label_NgSinh
            // 
            this.label_NgSinh.AutoSize = true;
            this.label_NgSinh.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgSinh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_NgSinh.Location = new System.Drawing.Point(522, 27);
            this.label_NgSinh.Name = "label_NgSinh";
            this.label_NgSinh.Size = new System.Drawing.Size(80, 20);
            this.label_NgSinh.TabIndex = 13;
            this.label_NgSinh.Text = "Ngày sinh";
            // 
            // textBox_Ngsinh
            // 
            this.textBox_Ngsinh.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Ngsinh.Location = new System.Drawing.Point(517, 50);
            this.textBox_Ngsinh.Name = "textBox_Ngsinh";
            this.textBox_Ngsinh.Size = new System.Drawing.Size(173, 32);
            this.textBox_Ngsinh.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(39, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "Địa chỉ";
            // 
            // textBox_DiaChi
            // 
            this.textBox_DiaChi.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_DiaChi.Location = new System.Drawing.Point(34, 159);
            this.textBox_DiaChi.Name = "textBox_DiaChi";
            this.textBox_DiaChi.Size = new System.Drawing.Size(656, 32);
            this.textBox_DiaChi.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(39, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 20);
            this.label4.TabIndex = 17;
            this.label4.Text = "SDT";
            // 
            // textBox_SDT
            // 
            this.textBox_SDT.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SDT.Location = new System.Drawing.Point(34, 261);
            this.textBox_SDT.Name = "textBox_SDT";
            this.textBox_SDT.Size = new System.Drawing.Size(162, 32);
            this.textBox_SDT.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(277, 238);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 20);
            this.label5.TabIndex = 19;
            this.label5.Text = "Mã Phòng";
            // 
            // textBox_PHG
            // 
            this.textBox_PHG.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_PHG.Location = new System.Drawing.Point(272, 261);
            this.textBox_PHG.Name = "textBox_PHG";
            this.textBox_PHG.Size = new System.Drawing.Size(166, 32);
            this.textBox_PHG.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(522, 238);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 20);
            this.label6.TabIndex = 21;
            this.label6.Text = "Người quản lý";
            // 
            // textBox_NQL
            // 
            this.textBox_NQL.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_NQL.Location = new System.Drawing.Point(517, 261);
            this.textBox_NQL.Name = "textBox_NQL";
            this.textBox_NQL.Size = new System.Drawing.Size(173, 32);
            this.textBox_NQL.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(39, 348);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 20);
            this.label7.TabIndex = 23;
            this.label7.Text = "Lương";
            // 
            // textBox_Luong
            // 
            this.textBox_Luong.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Luong.Location = new System.Drawing.Point(34, 371);
            this.textBox_Luong.Name = "textBox_Luong";
            this.textBox_Luong.Size = new System.Drawing.Size(162, 32);
            this.textBox_Luong.TabIndex = 22;
            // 
            // label_PhuCap
            // 
            this.label_PhuCap.AutoSize = true;
            this.label_PhuCap.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PhuCap.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_PhuCap.Location = new System.Drawing.Point(277, 348);
            this.label_PhuCap.Name = "label_PhuCap";
            this.label_PhuCap.Size = new System.Drawing.Size(66, 20);
            this.label_PhuCap.TabIndex = 25;
            this.label_PhuCap.Text = "Phụ cấp";
            // 
            // textBox_PhuCap
            // 
            this.textBox_PhuCap.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_PhuCap.Location = new System.Drawing.Point(272, 371);
            this.textBox_PhuCap.Name = "textBox_PhuCap";
            this.textBox_PhuCap.Size = new System.Drawing.Size(166, 32);
            this.textBox_PhuCap.TabIndex = 24;
            // 
            // guna2Button_Sua
            // 
            this.guna2Button_Sua.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Sua.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Sua.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_Sua.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_Sua.FillColor = System.Drawing.Color.White;
            this.guna2Button_Sua.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_Sua.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_Sua.Location = new System.Drawing.Point(549, 431);
            this.guna2Button_Sua.Name = "guna2Button_Sua";
            this.guna2Button_Sua.Size = new System.Drawing.Size(141, 45);
            this.guna2Button_Sua.TabIndex = 26;
            this.guna2Button_Sua.Text = "SỬA";
            this.guna2Button_Sua.Click += new System.EventHandler(this.guna2Button_Sua_Click);
            // 
            // guna2Button_Luu
            // 
            this.guna2Button_Luu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Luu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Luu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_Luu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_Luu.FillColor = System.Drawing.Color.White;
            this.guna2Button_Luu.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_Luu.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_Luu.Location = new System.Drawing.Point(382, 431);
            this.guna2Button_Luu.Name = "guna2Button_Luu";
            this.guna2Button_Luu.Size = new System.Drawing.Size(141, 45);
            this.guna2Button_Luu.TabIndex = 27;
            this.guna2Button_Luu.Text = "LƯU";
            // 
            // panel_CaNhan
            // 
            this.panel_CaNhan.Controls.Add(this.guna2Button_Luu);
            this.panel_CaNhan.Controls.Add(this.guna2Button_Sua);
            this.panel_CaNhan.Controls.Add(this.label_PhuCap);
            this.panel_CaNhan.Controls.Add(this.textBox_PhuCap);
            this.panel_CaNhan.Controls.Add(this.label7);
            this.panel_CaNhan.Controls.Add(this.textBox_Luong);
            this.panel_CaNhan.Controls.Add(this.label6);
            this.panel_CaNhan.Controls.Add(this.textBox_NQL);
            this.panel_CaNhan.Controls.Add(this.label5);
            this.panel_CaNhan.Controls.Add(this.textBox_PHG);
            this.panel_CaNhan.Controls.Add(this.label4);
            this.panel_CaNhan.Controls.Add(this.textBox_SDT);
            this.panel_CaNhan.Controls.Add(this.label3);
            this.panel_CaNhan.Controls.Add(this.textBox_DiaChi);
            this.panel_CaNhan.Controls.Add(this.label_NgSinh);
            this.panel_CaNhan.Controls.Add(this.textBox_Ngsinh);
            this.panel_CaNhan.Controls.Add(this.label_Phai);
            this.panel_CaNhan.Controls.Add(this.textBox_Phai);
            this.panel_CaNhan.Controls.Add(this.label_Hoten);
            this.panel_CaNhan.Controls.Add(this.textBox_Hoten);
            this.panel_CaNhan.Location = new System.Drawing.Point(363, 22);
            this.panel_CaNhan.Name = "panel_CaNhan";
            this.panel_CaNhan.Size = new System.Drawing.Size(729, 505);
            this.panel_CaNhan.TabIndex = 28;
            // 
            // guna2DataGridView_QL
            // 
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_QL.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView_QL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.guna2DataGridView_QL.ColumnHeadersHeight = 25;
            this.guna2DataGridView_QL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView_QL.DefaultCellStyle = dataGridViewCellStyle12;
            this.guna2DataGridView_QL.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_QL.Location = new System.Drawing.Point(300, 8);
            this.guna2DataGridView_QL.Name = "guna2DataGridView_QL";
            this.guna2DataGridView_QL.RowHeadersVisible = false;
            this.guna2DataGridView_QL.RowHeadersWidth = 53;
            this.guna2DataGridView_QL.RowTemplate.Height = 24;
            this.guna2DataGridView_QL.Size = new System.Drawing.Size(862, 564);
            this.guna2DataGridView_QL.TabIndex = 29;
            this.guna2DataGridView_QL.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_QL.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView_QL.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_QL.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_QL.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_QL.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_QL.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.Height = 25;
            this.guna2DataGridView_QL.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // Form_QL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(1174, 584);
            this.Controls.Add(this.panel_CaNhan);
            this.Controls.Add(this.guna2Button_PhanCong);
            this.Controls.Add(this.guna2Button_CongViec);
            this.Controls.Add(this.guna2Button_NhanVien);
            this.Controls.Add(this.guna2Button_PhongBan);
            this.Controls.Add(this.guna2Button_DeAn);
            this.Controls.Add(this.guna2Button_CaNhan);
            this.Controls.Add(this.textBox_ID);
            this.Controls.Add(this.guna2ImageButton1);
            this.Controls.Add(this.guna2DataGridView_QL);
            this.MaximumSize = new System.Drawing.Size(1192, 632);
            this.MinimumSize = new System.Drawing.Size(1192, 632);
            this.Name = "Form_QL";
            this.Text = "QUAN_LY";
            this.panel_CaNhan.ResumeLayout(false);
            this.panel_CaNhan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView_QL)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private System.Windows.Forms.TextBox textBox_ID;
        private Guna.UI2.WinForms.Guna2Button guna2Button_CaNhan;
        private Guna.UI2.WinForms.Guna2Button guna2Button_DeAn;
        private Guna.UI2.WinForms.Guna2Button guna2Button_PhongBan;
        private Guna.UI2.WinForms.Guna2Button guna2Button_NhanVien;
        private Guna.UI2.WinForms.Guna2Button guna2Button_CongViec;
        private Guna.UI2.WinForms.Guna2Button guna2Button_PhanCong;
        private System.Windows.Forms.TextBox textBox_Hoten;
        private System.Windows.Forms.Label label_Hoten;
        private System.Windows.Forms.Label label_Phai;
        private System.Windows.Forms.TextBox textBox_Phai;
        private System.Windows.Forms.Label label_NgSinh;
        private System.Windows.Forms.TextBox textBox_Ngsinh;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_DiaChi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_SDT;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_PHG;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_NQL;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_Luong;
        private System.Windows.Forms.Label label_PhuCap;
        private System.Windows.Forms.TextBox textBox_PhuCap;
        private Guna.UI2.WinForms.Guna2Button guna2Button_Sua;
        private Guna.UI2.WinForms.Guna2Button guna2Button_Luu;
        private System.Windows.Forms.Panel panel_CaNhan;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView_QL;
    }
}

