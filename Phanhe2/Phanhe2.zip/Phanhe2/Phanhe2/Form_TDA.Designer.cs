﻿namespace Phanhe2
{
    partial class Form_TDA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2DataGridView_QL = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2Button_CongViec = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_PhongBan = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_DeAn = new Guna.UI2.WinForms.Guna2Button();
            this.textBox_ID = new System.Windows.Forms.TextBox();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2Button_CaNhan = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_DA_Sua = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_DA_Them = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_DA_Xoa = new Guna.UI2.WinForms.Guna2Button();
            this.panel_DeAn = new System.Windows.Forms.Panel();
            this.panel_SuaDA = new System.Windows.Forms.Panel();
            this.comboBox_MaDA = new System.Windows.Forms.ComboBox();
            this.guna2Button_Huy_Sua = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_XN_Sua = new Guna.UI2.WinForms.Guna2Button();
            this.textBox_TenDA_Sua = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox_PHG_Sua = new System.Windows.Forms.ComboBox();
            this.dateTimePicker_NgBD_Sua = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel_ThemDA = new System.Windows.Forms.Panel();
            this.guna2Button_Huy = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_XN = new Guna.UI2.WinForms.Guna2Button();
            this.textBox_TenDA = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox_PHG = new System.Windows.Forms.ComboBox();
            this.dateTimePicker_NgBD = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_MaDA = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2DataGridView_DeAn = new Guna.UI2.WinForms.Guna2DataGridView();
            this.textBox_Hoten = new System.Windows.Forms.TextBox();
            this.label_Hoten = new System.Windows.Forms.Label();
            this.textBox_Phai = new System.Windows.Forms.TextBox();
            this.label_Phai = new System.Windows.Forms.Label();
            this.textBox_Ngsinh = new System.Windows.Forms.TextBox();
            this.label_NgSinh = new System.Windows.Forms.Label();
            this.textBox_DiaChi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_SDT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_PHG = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_NQL = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_Luong = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_PhuCap = new System.Windows.Forms.TextBox();
            this.label_PhuCap = new System.Windows.Forms.Label();
            this.guna2Button_Sua = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button_Luu = new Guna.UI2.WinForms.Guna2Button();
            this.panel_CaNhan = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView_QL)).BeginInit();
            this.panel_DeAn.SuspendLayout();
            this.panel_SuaDA.SuspendLayout();
            this.panel_ThemDA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView_DeAn)).BeginInit();
            this.panel_CaNhan.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2DataGridView_QL
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_QL.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView_QL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView_QL.ColumnHeadersHeight = 25;
            this.guna2DataGridView_QL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView_QL.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView_QL.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_QL.Location = new System.Drawing.Point(290, 14);
            this.guna2DataGridView_QL.Name = "guna2DataGridView_QL";
            this.guna2DataGridView_QL.RowHeadersVisible = false;
            this.guna2DataGridView_QL.RowHeadersWidth = 53;
            this.guna2DataGridView_QL.RowTemplate.Height = 24;
            this.guna2DataGridView_QL.Size = new System.Drawing.Size(862, 564);
            this.guna2DataGridView_QL.TabIndex = 39;
            this.guna2DataGridView_QL.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_QL.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView_QL.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_QL.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_QL.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_QL.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_QL.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView_QL.ThemeStyle.HeaderStyle.Height = 25;
            this.guna2DataGridView_QL.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_QL.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // guna2Button_CongViec
            // 
            this.guna2Button_CongViec.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_CongViec.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_CongViec.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_CongViec.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_CongViec.FillColor = System.Drawing.Color.White;
            this.guna2Button_CongViec.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_CongViec.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_CongViec.Location = new System.Drawing.Point(23, 329);
            this.guna2Button_CongViec.Name = "guna2Button_CongViec";
            this.guna2Button_CongViec.Size = new System.Drawing.Size(235, 45);
            this.guna2Button_CongViec.TabIndex = 36;
            this.guna2Button_CongViec.Text = "CÔNG VIỆC";
            this.guna2Button_CongViec.Click += new System.EventHandler(this.guna2Button_CongViec_Click);
            // 
            // guna2Button_PhongBan
            // 
            this.guna2Button_PhongBan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_PhongBan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_PhongBan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_PhongBan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_PhongBan.FillColor = System.Drawing.Color.White;
            this.guna2Button_PhongBan.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_PhongBan.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_PhongBan.Location = new System.Drawing.Point(23, 399);
            this.guna2Button_PhongBan.Name = "guna2Button_PhongBan";
            this.guna2Button_PhongBan.Size = new System.Drawing.Size(235, 45);
            this.guna2Button_PhongBan.TabIndex = 34;
            this.guna2Button_PhongBan.Text = "PHÒNG BAN";
            this.guna2Button_PhongBan.Click += new System.EventHandler(this.guna2Button_PhongBan_Click);
            // 
            // guna2Button_DeAn
            // 
            this.guna2Button_DeAn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_DeAn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_DeAn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_DeAn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_DeAn.FillColor = System.Drawing.Color.White;
            this.guna2Button_DeAn.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_DeAn.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_DeAn.Location = new System.Drawing.Point(23, 470);
            this.guna2Button_DeAn.Name = "guna2Button_DeAn";
            this.guna2Button_DeAn.Size = new System.Drawing.Size(235, 45);
            this.guna2Button_DeAn.TabIndex = 33;
            this.guna2Button_DeAn.Text = "ĐỀ ÁN";
            this.guna2Button_DeAn.Click += new System.EventHandler(this.guna2Button_DeAn_Click);
            // 
            // textBox_ID
            // 
            this.textBox_ID.BackColor = System.Drawing.Color.SeaGreen;
            this.textBox_ID.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_ID.ForeColor = System.Drawing.Color.White;
            this.textBox_ID.Location = new System.Drawing.Point(38, 207);
            this.textBox_ID.Name = "textBox_ID";
            this.textBox_ID.Size = new System.Drawing.Size(196, 32);
            this.textBox_ID.TabIndex = 31;
            this.textBox_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.Image = global::Phanhe2.Properties.Resources.Avatar;
            this.guna2ImageButton1.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.ImageSize = new System.Drawing.Size(155, 155);
            this.guna2ImageButton1.Location = new System.Drawing.Point(34, 6);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.Size = new System.Drawing.Size(211, 199);
            this.guna2ImageButton1.TabIndex = 30;
            // 
            // guna2Button_CaNhan
            // 
            this.guna2Button_CaNhan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_CaNhan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_CaNhan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_CaNhan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_CaNhan.FillColor = System.Drawing.Color.White;
            this.guna2Button_CaNhan.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_CaNhan.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_CaNhan.Location = new System.Drawing.Point(23, 255);
            this.guna2Button_CaNhan.Name = "guna2Button_CaNhan";
            this.guna2Button_CaNhan.Size = new System.Drawing.Size(235, 45);
            this.guna2Button_CaNhan.TabIndex = 32;
            this.guna2Button_CaNhan.Text = "CÁ NHÂN";
            this.guna2Button_CaNhan.Click += new System.EventHandler(this.guna2Button_CaNhan_Click);
            // 
            // guna2Button_DA_Sua
            // 
            this.guna2Button_DA_Sua.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_DA_Sua.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_DA_Sua.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_DA_Sua.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_DA_Sua.FillColor = System.Drawing.Color.LightGoldenrodYellow;
            this.guna2Button_DA_Sua.Font = new System.Drawing.Font("Cambria", 5.76F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_DA_Sua.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_DA_Sua.Location = new System.Drawing.Point(682, 0);
            this.guna2Button_DA_Sua.Name = "guna2Button_DA_Sua";
            this.guna2Button_DA_Sua.Size = new System.Drawing.Size(56, 26);
            this.guna2Button_DA_Sua.TabIndex = 28;
            this.guna2Button_DA_Sua.Text = "Sửa";
            this.guna2Button_DA_Sua.Click += new System.EventHandler(this.guna2Button_DA_Sua_Click);
            // 
            // guna2Button_DA_Them
            // 
            this.guna2Button_DA_Them.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_DA_Them.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_DA_Them.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_DA_Them.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_DA_Them.FillColor = System.Drawing.Color.LightGoldenrodYellow;
            this.guna2Button_DA_Them.Font = new System.Drawing.Font("Cambria", 5.184F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_DA_Them.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_DA_Them.Location = new System.Drawing.Point(744, 0);
            this.guna2Button_DA_Them.Name = "guna2Button_DA_Them";
            this.guna2Button_DA_Them.Size = new System.Drawing.Size(56, 26);
            this.guna2Button_DA_Them.TabIndex = 41;
            this.guna2Button_DA_Them.Text = "Thêm";
            this.guna2Button_DA_Them.TextFormatNoPrefix = true;
            this.guna2Button_DA_Them.Click += new System.EventHandler(this.guna2Button_DA_Them_Click);
            // 
            // guna2Button_DA_Xoa
            // 
            this.guna2Button_DA_Xoa.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_DA_Xoa.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_DA_Xoa.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_DA_Xoa.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_DA_Xoa.FillColor = System.Drawing.Color.LightGoldenrodYellow;
            this.guna2Button_DA_Xoa.Font = new System.Drawing.Font("Cambria", 5.76F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_DA_Xoa.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_DA_Xoa.Location = new System.Drawing.Point(806, 0);
            this.guna2Button_DA_Xoa.Name = "guna2Button_DA_Xoa";
            this.guna2Button_DA_Xoa.Size = new System.Drawing.Size(56, 26);
            this.guna2Button_DA_Xoa.TabIndex = 42;
            this.guna2Button_DA_Xoa.Text = "Xóa";
            this.guna2Button_DA_Xoa.Click += new System.EventHandler(this.guna2Button_DA_Xoa_Click);
            // 
            // panel_DeAn
            // 
            this.panel_DeAn.Controls.Add(this.panel_SuaDA);
            this.panel_DeAn.Controls.Add(this.panel_ThemDA);
            this.panel_DeAn.Controls.Add(this.guna2DataGridView_DeAn);
            this.panel_DeAn.Controls.Add(this.guna2Button_DA_Xoa);
            this.panel_DeAn.Controls.Add(this.guna2Button_DA_Sua);
            this.panel_DeAn.Controls.Add(this.guna2Button_DA_Them);
            this.panel_DeAn.Location = new System.Drawing.Point(290, 6);
            this.panel_DeAn.Name = "panel_DeAn";
            this.panel_DeAn.Size = new System.Drawing.Size(862, 572);
            this.panel_DeAn.TabIndex = 43;
            // 
            // panel_SuaDA
            // 
            this.panel_SuaDA.Controls.Add(this.comboBox_MaDA);
            this.panel_SuaDA.Controls.Add(this.guna2Button_Huy_Sua);
            this.panel_SuaDA.Controls.Add(this.guna2Button_XN_Sua);
            this.panel_SuaDA.Controls.Add(this.textBox_TenDA_Sua);
            this.panel_SuaDA.Controls.Add(this.label11);
            this.panel_SuaDA.Controls.Add(this.label12);
            this.panel_SuaDA.Controls.Add(this.label13);
            this.panel_SuaDA.Controls.Add(this.comboBox_PHG_Sua);
            this.panel_SuaDA.Controls.Add(this.dateTimePicker_NgBD_Sua);
            this.panel_SuaDA.Controls.Add(this.label14);
            this.panel_SuaDA.Controls.Add(this.label15);
            this.panel_SuaDA.Location = new System.Drawing.Point(45, 283);
            this.panel_SuaDA.Name = "panel_SuaDA";
            this.panel_SuaDA.Size = new System.Drawing.Size(785, 202);
            this.panel_SuaDA.TabIndex = 45;
            // 
            // comboBox_MaDA
            // 
            this.comboBox_MaDA.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_MaDA.FormattingEnabled = true;
            this.comboBox_MaDA.Location = new System.Drawing.Point(25, 114);
            this.comboBox_MaDA.Name = "comboBox_MaDA";
            this.comboBox_MaDA.Size = new System.Drawing.Size(121, 33);
            this.comboBox_MaDA.TabIndex = 44;
            // 
            // guna2Button_Huy_Sua
            // 
            this.guna2Button_Huy_Sua.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Huy_Sua.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Huy_Sua.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_Huy_Sua.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_Huy_Sua.FillColor = System.Drawing.Color.LightGoldenrodYellow;
            this.guna2Button_Huy_Sua.Font = new System.Drawing.Font("Cambria", 5.184F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_Huy_Sua.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_Huy_Sua.Location = new System.Drawing.Point(633, 168);
            this.guna2Button_Huy_Sua.Name = "guna2Button_Huy_Sua";
            this.guna2Button_Huy_Sua.Size = new System.Drawing.Size(85, 26);
            this.guna2Button_Huy_Sua.TabIndex = 43;
            this.guna2Button_Huy_Sua.Text = "Hủy";
            this.guna2Button_Huy_Sua.TextFormatNoPrefix = true;
            this.guna2Button_Huy_Sua.Click += new System.EventHandler(this.guna2Button_Huy_Sua_Click);
            // 
            // guna2Button_XN_Sua
            // 
            this.guna2Button_XN_Sua.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_XN_Sua.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_XN_Sua.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_XN_Sua.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_XN_Sua.FillColor = System.Drawing.Color.LightGoldenrodYellow;
            this.guna2Button_XN_Sua.Font = new System.Drawing.Font("Cambria", 5.184F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_XN_Sua.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_XN_Sua.Location = new System.Drawing.Point(542, 168);
            this.guna2Button_XN_Sua.Name = "guna2Button_XN_Sua";
            this.guna2Button_XN_Sua.Size = new System.Drawing.Size(85, 26);
            this.guna2Button_XN_Sua.TabIndex = 42;
            this.guna2Button_XN_Sua.Text = "Xác nhận";
            this.guna2Button_XN_Sua.TextFormatNoPrefix = true;
            this.guna2Button_XN_Sua.Click += new System.EventHandler(this.guna2Button_XN_Sua_Click);
            // 
            // textBox_TenDA_Sua
            // 
            this.textBox_TenDA_Sua.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TenDA_Sua.Location = new System.Drawing.Point(167, 115);
            this.textBox_TenDA_Sua.Name = "textBox_TenDA_Sua";
            this.textBox_TenDA_Sua.Size = new System.Drawing.Size(130, 32);
            this.textBox_TenDA_Sua.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cambria", 10.944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(640, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 22);
            this.label11.TabIndex = 8;
            this.label11.Text = "Phòng";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Cambria", 10.944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(302, 93);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(119, 22);
            this.label12.TabIndex = 7;
            this.label12.Text = "Ngày Bắt Đầu";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Cambria", 10.944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(163, 90);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 22);
            this.label13.TabIndex = 6;
            this.label13.Text = "Tên Đề Án";
            // 
            // comboBox_PHG_Sua
            // 
            this.comboBox_PHG_Sua.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_PHG_Sua.FormattingEnabled = true;
            this.comboBox_PHG_Sua.Location = new System.Drawing.Point(644, 115);
            this.comboBox_PHG_Sua.Name = "comboBox_PHG_Sua";
            this.comboBox_PHG_Sua.Size = new System.Drawing.Size(121, 33);
            this.comboBox_PHG_Sua.TabIndex = 4;
            // 
            // dateTimePicker_NgBD_Sua
            // 
            this.dateTimePicker_NgBD_Sua.CalendarFont = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgBD_Sua.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgBD_Sua.Location = new System.Drawing.Point(309, 115);
            this.dateTimePicker_NgBD_Sua.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker_NgBD_Sua.Name = "dateTimePicker_NgBD_Sua";
            this.dateTimePicker_NgBD_Sua.Size = new System.Drawing.Size(329, 32);
            this.dateTimePicker_NgBD_Sua.TabIndex = 3;
            this.dateTimePicker_NgBD_Sua.Value = new System.DateTime(2023, 6, 27, 0, 0, 0, 0);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Cambria", 10.944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(21, 90);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 22);
            this.label14.TabIndex = 2;
            this.label14.Text = "Mã Đề Án";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Cambria", 21.888F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Moccasin;
            this.label15.Location = new System.Drawing.Point(292, 24);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(207, 44);
            this.label15.TabIndex = 0;
            this.label15.Text = "SỬA ĐỀ ÁN";
            // 
            // panel_ThemDA
            // 
            this.panel_ThemDA.Controls.Add(this.guna2Button_Huy);
            this.panel_ThemDA.Controls.Add(this.guna2Button_XN);
            this.panel_ThemDA.Controls.Add(this.textBox_TenDA);
            this.panel_ThemDA.Controls.Add(this.label10);
            this.panel_ThemDA.Controls.Add(this.label9);
            this.panel_ThemDA.Controls.Add(this.label8);
            this.panel_ThemDA.Controls.Add(this.comboBox_PHG);
            this.panel_ThemDA.Controls.Add(this.dateTimePicker_NgBD);
            this.panel_ThemDA.Controls.Add(this.label2);
            this.panel_ThemDA.Controls.Add(this.textBox_MaDA);
            this.panel_ThemDA.Controls.Add(this.label1);
            this.panel_ThemDA.Location = new System.Drawing.Point(45, 60);
            this.panel_ThemDA.Name = "panel_ThemDA";
            this.panel_ThemDA.Size = new System.Drawing.Size(785, 197);
            this.panel_ThemDA.TabIndex = 44;
            // 
            // guna2Button_Huy
            // 
            this.guna2Button_Huy.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Huy.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Huy.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_Huy.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_Huy.FillColor = System.Drawing.Color.LightGoldenrodYellow;
            this.guna2Button_Huy.Font = new System.Drawing.Font("Cambria", 5.184F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_Huy.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_Huy.Location = new System.Drawing.Point(633, 168);
            this.guna2Button_Huy.Name = "guna2Button_Huy";
            this.guna2Button_Huy.Size = new System.Drawing.Size(85, 26);
            this.guna2Button_Huy.TabIndex = 43;
            this.guna2Button_Huy.Text = "Hủy";
            this.guna2Button_Huy.TextFormatNoPrefix = true;
            this.guna2Button_Huy.Click += new System.EventHandler(this.guna2Button_Huy_Click);
            // 
            // guna2Button_XN
            // 
            this.guna2Button_XN.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_XN.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_XN.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_XN.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_XN.FillColor = System.Drawing.Color.LightGoldenrodYellow;
            this.guna2Button_XN.Font = new System.Drawing.Font("Cambria", 5.184F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_XN.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_XN.Location = new System.Drawing.Point(542, 168);
            this.guna2Button_XN.Name = "guna2Button_XN";
            this.guna2Button_XN.Size = new System.Drawing.Size(85, 26);
            this.guna2Button_XN.TabIndex = 42;
            this.guna2Button_XN.Text = "Xác nhận";
            this.guna2Button_XN.TextFormatNoPrefix = true;
            this.guna2Button_XN.Click += new System.EventHandler(this.guna2Button_XN_Click);
            // 
            // textBox_TenDA
            // 
            this.textBox_TenDA.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TenDA.Location = new System.Drawing.Point(167, 115);
            this.textBox_TenDA.Name = "textBox_TenDA";
            this.textBox_TenDA.Size = new System.Drawing.Size(130, 32);
            this.textBox_TenDA.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cambria", 10.944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(640, 90);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 22);
            this.label10.TabIndex = 8;
            this.label10.Text = "Phòng";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cambria", 10.944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(302, 93);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 22);
            this.label9.TabIndex = 7;
            this.label9.Text = "Ngày Bắt Đầu";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 10.944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(163, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 22);
            this.label8.TabIndex = 6;
            this.label8.Text = "Tên Đề Án";
            // 
            // comboBox_PHG
            // 
            this.comboBox_PHG.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_PHG.FormattingEnabled = true;
            this.comboBox_PHG.Location = new System.Drawing.Point(644, 115);
            this.comboBox_PHG.Name = "comboBox_PHG";
            this.comboBox_PHG.Size = new System.Drawing.Size(121, 33);
            this.comboBox_PHG.TabIndex = 4;
            // 
            // dateTimePicker_NgBD
            // 
            this.dateTimePicker_NgBD.CalendarFont = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgBD.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgBD.Location = new System.Drawing.Point(309, 115);
            this.dateTimePicker_NgBD.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker_NgBD.Name = "dateTimePicker_NgBD";
            this.dateTimePicker_NgBD.Size = new System.Drawing.Size(329, 32);
            this.dateTimePicker_NgBD.TabIndex = 3;
            this.dateTimePicker_NgBD.Value = new System.DateTime(2023, 6, 27, 0, 0, 0, 0);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 10.944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(21, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Mã Đề Án";
            // 
            // textBox_MaDA
            // 
            this.textBox_MaDA.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_MaDA.ForeColor = System.Drawing.Color.Black;
            this.textBox_MaDA.Location = new System.Drawing.Point(25, 115);
            this.textBox_MaDA.Name = "textBox_MaDA";
            this.textBox_MaDA.Size = new System.Drawing.Size(130, 32);
            this.textBox_MaDA.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 21.888F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Moccasin;
            this.label1.Location = new System.Drawing.Point(264, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "THÊM ĐỀ ÁN";
            // 
            // guna2DataGridView_DeAn
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_DeAn.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView_DeAn.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.guna2DataGridView_DeAn.ColumnHeadersHeight = 40;
            this.guna2DataGridView_DeAn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView_DeAn.DefaultCellStyle = dataGridViewCellStyle6;
            this.guna2DataGridView_DeAn.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_DeAn.Location = new System.Drawing.Point(3, 32);
            this.guna2DataGridView_DeAn.Name = "guna2DataGridView_DeAn";
            this.guna2DataGridView_DeAn.RowHeadersVisible = false;
            this.guna2DataGridView_DeAn.RowHeadersWidth = 53;
            this.guna2DataGridView_DeAn.RowTemplate.Height = 24;
            this.guna2DataGridView_DeAn.Size = new System.Drawing.Size(858, 539);
            this.guna2DataGridView_DeAn.TabIndex = 43;
            this.guna2DataGridView_DeAn.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_DeAn.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView_DeAn.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_DeAn.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_DeAn.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_DeAn.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_DeAn.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_DeAn.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_DeAn.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView_DeAn.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView_DeAn.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView_DeAn.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView_DeAn.ThemeStyle.HeaderStyle.Height = 40;
            this.guna2DataGridView_DeAn.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView_DeAn.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_DeAn.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView_DeAn.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.488F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView_DeAn.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView_DeAn.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView_DeAn.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_DeAn.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // textBox_Hoten
            // 
            this.textBox_Hoten.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Hoten.Location = new System.Drawing.Point(34, 50);
            this.textBox_Hoten.Name = "textBox_Hoten";
            this.textBox_Hoten.Size = new System.Drawing.Size(162, 32);
            this.textBox_Hoten.TabIndex = 8;
            // 
            // label_Hoten
            // 
            this.label_Hoten.AutoSize = true;
            this.label_Hoten.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Hoten.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_Hoten.Location = new System.Drawing.Point(39, 27);
            this.label_Hoten.Name = "label_Hoten";
            this.label_Hoten.Size = new System.Drawing.Size(57, 20);
            this.label_Hoten.TabIndex = 9;
            this.label_Hoten.Text = "Họ tên";
            // 
            // textBox_Phai
            // 
            this.textBox_Phai.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Phai.Location = new System.Drawing.Point(272, 50);
            this.textBox_Phai.Name = "textBox_Phai";
            this.textBox_Phai.Size = new System.Drawing.Size(166, 32);
            this.textBox_Phai.TabIndex = 10;
            // 
            // label_Phai
            // 
            this.label_Phai.AutoSize = true;
            this.label_Phai.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Phai.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_Phai.Location = new System.Drawing.Point(277, 27);
            this.label_Phai.Name = "label_Phai";
            this.label_Phai.Size = new System.Drawing.Size(41, 20);
            this.label_Phai.TabIndex = 11;
            this.label_Phai.Text = "Phái";
            // 
            // textBox_Ngsinh
            // 
            this.textBox_Ngsinh.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Ngsinh.Location = new System.Drawing.Point(517, 50);
            this.textBox_Ngsinh.Name = "textBox_Ngsinh";
            this.textBox_Ngsinh.Size = new System.Drawing.Size(173, 32);
            this.textBox_Ngsinh.TabIndex = 12;
            // 
            // label_NgSinh
            // 
            this.label_NgSinh.AutoSize = true;
            this.label_NgSinh.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgSinh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_NgSinh.Location = new System.Drawing.Point(522, 27);
            this.label_NgSinh.Name = "label_NgSinh";
            this.label_NgSinh.Size = new System.Drawing.Size(80, 20);
            this.label_NgSinh.TabIndex = 13;
            this.label_NgSinh.Text = "Ngày sinh";
            // 
            // textBox_DiaChi
            // 
            this.textBox_DiaChi.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_DiaChi.Location = new System.Drawing.Point(34, 159);
            this.textBox_DiaChi.Name = "textBox_DiaChi";
            this.textBox_DiaChi.Size = new System.Drawing.Size(656, 32);
            this.textBox_DiaChi.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(39, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "Địa chỉ";
            // 
            // textBox_SDT
            // 
            this.textBox_SDT.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SDT.Location = new System.Drawing.Point(34, 261);
            this.textBox_SDT.Name = "textBox_SDT";
            this.textBox_SDT.Size = new System.Drawing.Size(162, 32);
            this.textBox_SDT.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(39, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 20);
            this.label4.TabIndex = 17;
            this.label4.Text = "SDT";
            // 
            // textBox_PHG
            // 
            this.textBox_PHG.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_PHG.Location = new System.Drawing.Point(272, 261);
            this.textBox_PHG.Name = "textBox_PHG";
            this.textBox_PHG.Size = new System.Drawing.Size(166, 32);
            this.textBox_PHG.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(277, 238);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 20);
            this.label5.TabIndex = 19;
            this.label5.Text = "Mã Phòng";
            // 
            // textBox_NQL
            // 
            this.textBox_NQL.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_NQL.Location = new System.Drawing.Point(517, 261);
            this.textBox_NQL.Name = "textBox_NQL";
            this.textBox_NQL.Size = new System.Drawing.Size(173, 32);
            this.textBox_NQL.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(522, 238);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 20);
            this.label6.TabIndex = 21;
            this.label6.Text = "Người quản lý";
            // 
            // textBox_Luong
            // 
            this.textBox_Luong.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Luong.Location = new System.Drawing.Point(34, 371);
            this.textBox_Luong.Name = "textBox_Luong";
            this.textBox_Luong.Size = new System.Drawing.Size(162, 32);
            this.textBox_Luong.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(39, 348);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 20);
            this.label7.TabIndex = 23;
            this.label7.Text = "Lương";
            // 
            // textBox_PhuCap
            // 
            this.textBox_PhuCap.Font = new System.Drawing.Font("Cambria", 12.096F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_PhuCap.Location = new System.Drawing.Point(272, 371);
            this.textBox_PhuCap.Name = "textBox_PhuCap";
            this.textBox_PhuCap.Size = new System.Drawing.Size(166, 32);
            this.textBox_PhuCap.TabIndex = 24;
            // 
            // label_PhuCap
            // 
            this.label_PhuCap.AutoSize = true;
            this.label_PhuCap.Font = new System.Drawing.Font("Cambria", 9.792F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PhuCap.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label_PhuCap.Location = new System.Drawing.Point(277, 348);
            this.label_PhuCap.Name = "label_PhuCap";
            this.label_PhuCap.Size = new System.Drawing.Size(66, 20);
            this.label_PhuCap.TabIndex = 25;
            this.label_PhuCap.Text = "Phụ cấp";
            // 
            // guna2Button_Sua
            // 
            this.guna2Button_Sua.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Sua.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Sua.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_Sua.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_Sua.FillColor = System.Drawing.Color.White;
            this.guna2Button_Sua.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_Sua.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_Sua.Location = new System.Drawing.Point(549, 431);
            this.guna2Button_Sua.Name = "guna2Button_Sua";
            this.guna2Button_Sua.Size = new System.Drawing.Size(141, 45);
            this.guna2Button_Sua.TabIndex = 26;
            this.guna2Button_Sua.Text = "SỬA";
            this.guna2Button_Sua.Click += new System.EventHandler(this.guna2Button_Sua_Click);
            // 
            // guna2Button_Luu
            // 
            this.guna2Button_Luu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Luu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button_Luu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button_Luu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button_Luu.FillColor = System.Drawing.Color.White;
            this.guna2Button_Luu.Font = new System.Drawing.Font("Cambria", 13.824F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button_Luu.ForeColor = System.Drawing.Color.DarkCyan;
            this.guna2Button_Luu.Location = new System.Drawing.Point(382, 431);
            this.guna2Button_Luu.Name = "guna2Button_Luu";
            this.guna2Button_Luu.Size = new System.Drawing.Size(141, 45);
            this.guna2Button_Luu.TabIndex = 27;
            this.guna2Button_Luu.Text = "LƯU";
            // 
            // panel_CaNhan
            // 
            this.panel_CaNhan.Controls.Add(this.guna2Button_Luu);
            this.panel_CaNhan.Controls.Add(this.guna2Button_Sua);
            this.panel_CaNhan.Controls.Add(this.label_PhuCap);
            this.panel_CaNhan.Controls.Add(this.textBox_PhuCap);
            this.panel_CaNhan.Controls.Add(this.label7);
            this.panel_CaNhan.Controls.Add(this.textBox_Luong);
            this.panel_CaNhan.Controls.Add(this.label6);
            this.panel_CaNhan.Controls.Add(this.textBox_NQL);
            this.panel_CaNhan.Controls.Add(this.label5);
            this.panel_CaNhan.Controls.Add(this.textBox_PHG);
            this.panel_CaNhan.Controls.Add(this.label4);
            this.panel_CaNhan.Controls.Add(this.textBox_SDT);
            this.panel_CaNhan.Controls.Add(this.label3);
            this.panel_CaNhan.Controls.Add(this.textBox_DiaChi);
            this.panel_CaNhan.Controls.Add(this.label_NgSinh);
            this.panel_CaNhan.Controls.Add(this.textBox_Ngsinh);
            this.panel_CaNhan.Controls.Add(this.label_Phai);
            this.panel_CaNhan.Controls.Add(this.textBox_Phai);
            this.panel_CaNhan.Controls.Add(this.label_Hoten);
            this.panel_CaNhan.Controls.Add(this.textBox_Hoten);
            this.panel_CaNhan.Location = new System.Drawing.Point(353, 28);
            this.panel_CaNhan.Name = "panel_CaNhan";
            this.panel_CaNhan.Size = new System.Drawing.Size(729, 505);
            this.panel_CaNhan.TabIndex = 38;
            // 
            // Form_TDA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(1174, 584);
            this.Controls.Add(this.panel_DeAn);
            this.Controls.Add(this.panel_CaNhan);
            this.Controls.Add(this.guna2Button_CongViec);
            this.Controls.Add(this.guna2Button_PhongBan);
            this.Controls.Add(this.guna2Button_DeAn);
            this.Controls.Add(this.textBox_ID);
            this.Controls.Add(this.guna2ImageButton1);
            this.Controls.Add(this.guna2Button_CaNhan);
            this.Controls.Add(this.guna2DataGridView_QL);
            this.MaximumSize = new System.Drawing.Size(1192, 632);
            this.MinimumSize = new System.Drawing.Size(1192, 632);
            this.Name = "Form_TDA";
            this.Text = "Form_TDA";
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView_QL)).EndInit();
            this.panel_DeAn.ResumeLayout(false);
            this.panel_SuaDA.ResumeLayout(false);
            this.panel_SuaDA.PerformLayout();
            this.panel_ThemDA.ResumeLayout(false);
            this.panel_ThemDA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView_DeAn)).EndInit();
            this.panel_CaNhan.ResumeLayout(false);
            this.panel_CaNhan.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView_QL;
        private Guna.UI2.WinForms.Guna2Button guna2Button_CongViec;
        private Guna.UI2.WinForms.Guna2Button guna2Button_PhongBan;
        private Guna.UI2.WinForms.Guna2Button guna2Button_DeAn;
        private System.Windows.Forms.TextBox textBox_ID;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private Guna.UI2.WinForms.Guna2Button guna2Button_CaNhan;
        private Guna.UI2.WinForms.Guna2Button guna2Button_DA_Sua;
        private Guna.UI2.WinForms.Guna2Button guna2Button_DA_Them;
        private Guna.UI2.WinForms.Guna2Button guna2Button_DA_Xoa;
        private System.Windows.Forms.Panel panel_DeAn;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView_DeAn;
        private System.Windows.Forms.Panel panel_CaNhan;
        private Guna.UI2.WinForms.Guna2Button guna2Button_Luu;
        private Guna.UI2.WinForms.Guna2Button guna2Button_Sua;
        private System.Windows.Forms.Label label_PhuCap;
        private System.Windows.Forms.TextBox textBox_PhuCap;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_Luong;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_NQL;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_PHG;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_SDT;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_DiaChi;
        private System.Windows.Forms.Label label_NgSinh;
        private System.Windows.Forms.TextBox textBox_Ngsinh;
        private System.Windows.Forms.Label label_Phai;
        private System.Windows.Forms.TextBox textBox_Phai;
        private System.Windows.Forms.Label label_Hoten;
        private System.Windows.Forms.TextBox textBox_Hoten;
        private System.Windows.Forms.Panel panel_ThemDA;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox_PHG;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgBD;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_MaDA;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button guna2Button_XN;
        private System.Windows.Forms.TextBox textBox_TenDA;
        private Guna.UI2.WinForms.Guna2Button guna2Button_Huy;
        private System.Windows.Forms.Panel panel_SuaDA;
        private System.Windows.Forms.ComboBox comboBox_MaDA;
        private Guna.UI2.WinForms.Guna2Button guna2Button_Huy_Sua;
        private Guna.UI2.WinForms.Guna2Button guna2Button_XN_Sua;
        private System.Windows.Forms.TextBox textBox_TenDA_Sua;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox_PHG_Sua;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgBD_Sua;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
    }
}